﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Complex_Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            ComplexCalculator calc = new ComplexCalculator();
            calc.RunCalculator();
        }
    }
}
